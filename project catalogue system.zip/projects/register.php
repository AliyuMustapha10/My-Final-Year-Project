<?php
require('dbconn.php');
?>


<!DOCTYPE html>
<html>

<!-- Head -->
<head>

	<title>Project Catalogue System </title>

	<!-- Meta-Tags -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="keywords" content="Library Member Login Form Widget Responsive, Login Form Web Template, Flat Pricing Tables, Flat Drop-Downs, Sign-Up Web Templates, Flat Web Templates, Login Sign-up Responsive Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design" />
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- //Meta-Tags -->

	<!-- Style --> <link rel="stylesheet" href="css/styles.css" type="text/css" media="all">

	<!-- Fonts -->
		<link href="//fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
	<!-- //Fonts -->

</head>
<!-- //Head -->

<!-- Body -->
<body>

	<h1 style="text-shadow: 2px 2px 1px #000, 4px 4px 3px #40e0d0">PROJECT CATALOGUE SYSTEM</h1>

	<div class="container">

		<div class="login">
			<!-- <h2>STUDENT PROJECT CATALOGUE SYSTEM</h2> -->
            <img src="images/buk.png" alt="buk logo" width="350" height="450">
		</div>

		<div class="register">
			<h2>Register</h2>
			<form action="register.php" method="post">
				<input type="text" Name="Name" placeholder="Name" required>
				<input type="text" Name="RegNo" placeholder="Registration Number" required="">
				<input type="text" Name="Email" placeholder="Email" required>
				<input type="password" Name="Password" placeholder="Password" required>
				<!-- <input type="password" Name="CPassword" placeholder="Confirm Password" required> -->
				
				<select name="Department" id="Department">
					<option value="Computer Science">Computer Science</option>
					<option value="Software Engineering">Software Engineering</option>
					<option value="Cyber Security">Cyber Security</option>
					<option value="Information Technology">Information Technology</option>
				</select>
				<br>
			
			
			<br>
			<div class="send-button">
			    <input type="submit" name="signup" value="Sign Up">
			    </form>
			</div>
			<p style="color: #fff"> Already have an account <a style="color: #40e0d0" href="index.php">Sign in here</a></p>
			<div class="clear"></div>
		</div>

		<div class="clear"></div>

	</div>

	<div class="footer w3layouts agileits">
		<p> &copy; 2018 Library Member Login. All Rights Reserved </a></p>
		
	</div>

<?php

if(isset($_POST['signup']))
{
	$name=$_POST['Name'];
	$email=$_POST['Email'];
	$password=$_POST['Password'];
	$regno=$_POST['RegNo'];
	$department=$_POST['Department'];
	$type='Student';

	$sql="insert into LMS.user (Name,Type,Department,RegNo,EmailId,Password) values ('$name','$type','$department','$regno','$email','$password')";

	if ($conn->query($sql) === TRUE) {
		echo "<script type='text/javascript'>alert('Registration Successful')</script>";
		header( "Refresh:0.01; url=index.php", true, 303);
	} else {
    //echo "Error: " . $sql . "<br>" . $conn->error;
		echo "<script type='text/javascript'>alert('User Exists')</script>";

	}
}

?>

</body>
<!-- //Body -->

</html>
