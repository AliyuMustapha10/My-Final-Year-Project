-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2024 at 03:48 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lms`
--

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `M_Id` int(10) NOT NULL,
  `RegNo` varchar(50) DEFAULT NULL,
  `Msg` varchar(255) DEFAULT NULL,
  `Receiver` varchar(255) DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `Time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`M_Id`, `RegNo`, `Msg`, `Receiver`, `Date`, `Time`) VALUES
(43, 'CST/18/COM/00115', 'okay user dont worry we will upload it soon', NULL, '2024-04-02', '11:00:27'),
(44, 'CST/18/COM/00115', 'Hi user', NULL, '2024-04-03', '11:39:42'),
(46, 'CST/18/COM/00115', 'good morning', 'CST/18/COM/00115', '2024-04-03', '12:51:14');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `ProjectId` int(10) NOT NULL,
  `Title` varchar(50) DEFAULT NULL,
  `Supervisor` varchar(50) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `Date` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`ProjectId`, `Title`, `Supervisor`, `Description`, `Date`) VALUES
(39, 'Design and Implementation of Project Catalogue Sys', 'zahraddeen babagana', 'web based project catalogue', '2024'),
(40, 'Design and Implementation of Library Management Sy', 'Haruna Rashid Ph.D', 'to help student to borrow books easily', '2021'),
(41, 'Online Web Store', 'Dr. Musa Isah Dandago', 'web store to transact online', '2018'),
(42, 'implementation', 'Mal. Musa Isah Dandago', 'another project', 'today'),
(43, 'horoscope data analysis', 'Haruna Rashid Ph.D', 'data analysis guidelines', 'today'),
(44, 'design & implementation', 'Haruna Rashid Ph.D', 'not selected', 'today'),
(45, 'second tester is here', 'Haruna Rashid Ph.D', 'dont', '2024-04-03');

-- --------------------------------------------------------

--
-- Table structure for table `supervisors`
--

CREATE TABLE `supervisors` (
  `SupervisorId` int(11) NOT NULL,
  `Supervisor_name` varchar(255) DEFAULT NULL,
  `Qualification` varchar(255) DEFAULT NULL,
  `Specialisation` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supervisors`
--

INSERT INTO `supervisors` (`SupervisorId`, `Supervisor_name`, `Qualification`, `Specialisation`) VALUES
(2, 'zahraddeen babagana', 'master', 'software engineering'),
(3, 'Jaafar Naabba', 'PhD', 'Artificial Intelligence');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `RegNo` varchar(50) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `Department` varchar(50) DEFAULT NULL,
  `EmailId` varchar(50) DEFAULT NULL,
  `Password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`RegNo`, `Name`, `Type`, `Department`, `EmailId`, `Password`) VALUES
('ADMIN', 'admin', 'Admin', NULL, 'admin@gmail.com', 'admin'),
('CST/18/COM/00110', 'Aliyu Mustapha', 'Student', 'Cyber Security', 'aliyu2@gmail.com', '1234'),
('CST/18/COM/00111', 'Usman Zunnurain', 'Student', 'Computer Science', 'uzu@gmail.com', '1234'),
('CST/18/COM/00115', 'Aliyu Mustapha Umar', 'Student', 'Cyber Security', 'aliyumustapha@gmail.com', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`M_Id`),
  ADD KEY `RollNo` (`RegNo`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`ProjectId`);

--
-- Indexes for table `supervisors`
--
ALTER TABLE `supervisors`
  ADD PRIMARY KEY (`SupervisorId`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`RegNo`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `M_Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `ProjectId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `supervisors`
--
ALTER TABLE `supervisors`
  MODIFY `SupervisorId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `message_ibfk_1` FOREIGN KEY (`RegNo`) REFERENCES `user` (`RegNo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
