<?php
require('dbconn.php');

$regno=$_GET['id'];



$sql1="delete from LMS.message where RegNo='$regno'";

if($conn->query($sql1) === TRUE)
{
    $sql2="delete from LMS.user where RegNo='$regno'";
    if($conn->query($sql2) === TRUE)
    {
        echo "<script type='text/javascript'>alert('User Removed Successfully')</script>";
        header( "Refresh:0.01; url=student.php", true, 303);
    }
    else
    {
	    echo "<script type='text/javascript'>alert('Error')</script>";
        header( "Refresh:0.01; url=student.php", true, 303);

    }
}
else
{
	echo "<script type='text/javascript'>alert('Error')</script>";
    header( "Refresh:0.01; url=student.php", true, 303);

}




?>