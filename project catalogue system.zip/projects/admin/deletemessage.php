<?php
require('dbconn.php');

$msg_id=$_GET['id'];



$sql="delete from LMS.message where M_Id='$msg_id'";

if($conn->query($sql) === TRUE)
{
echo "<script type='text/javascript'>alert('Message Deleted Successfully')</script>";
header( "Refresh:0.01; url=message.php", true, 303);
}
else
{
	echo "<script type='text/javascript'>alert('Error')</script>";
    header( "Refresh:0.01; url=message.php", true, 303);

}




?>