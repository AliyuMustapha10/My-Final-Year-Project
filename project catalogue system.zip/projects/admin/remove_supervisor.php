<?php
require('dbconn.php');

$supervisor_id=$_GET['id'];



$sql="delete from LMS.supervisors where SupervisorId='$supervisor_id'";

if($conn->query($sql) === TRUE)
{
echo "<script type='text/javascript'>alert('Message Deleted Successfully')</script>";
header( "Refresh:0.01; url=supervisor.php", true, 303);
}
else
{
	echo "<script type='text/javascript'>alert('Error')</script>";
    header( "Refresh:0.01; url=supervisor.php", true, 303);

}




?>