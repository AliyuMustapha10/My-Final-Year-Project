<?php
require('dbconn.php');
?>


<!DOCTYPE html>
<html>

<!-- Head -->
<head>

	<title>Project Catalague System </title>

	<!-- Meta-Tags -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="keywords" content="Library Member Login Form Widget Responsive, Login Form Web Template, Flat Pricing Tables, Flat Drop-Downs, Sign-Up Web Templates, Flat Web Templates, Login Sign-up Responsive Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design" />
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- //Meta-Tags -->

	<!-- Style --> <link rel="stylesheet" href="css/styles.css" type="text/css" media="all">

	<!-- Fonts -->
		<link href="//fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900" rel="stylesheet">
	<!-- //Fonts -->

</head>
<!-- //Head -->

<!-- Body -->
<body>

	<h1 style="text-shadow: 2px 2px 1px #000, 4px 4px 3px #40e0d0">PROJECT CATALOGUE SYSTEM</h1>

	<div class="container">

		<div class="login">
			<h2>Sign In</h2>
			<form action="index.php" method="post">
				<input type="text" Name="RegNo" placeholder="Registration Number" required="">
				<input type="password" Name="Password" placeholder="Password" required="">
			
			
			<div class="send-button">
				<!--<form>-->
					<input type="submit" name="signin"; value="Sign In">
				</form>
			</div>
			<p style="color: #fff"> If you dont have an account <a style="color: #40e0d0" href="register.php">Register Here</a></p><br>
			<p style="color: #fff; text-align: center"> <a style="color: #40e0d0" href="register.php">forgot password?</a></p>
			
			<div class="clear"></div>
		</div>

		<div class="register">
			<!-- <h2>FACULTY OF COMPUTING</h2> -->
			<img src="images/buk.png" alt="buk logo" width="350" height="450">
		</div>

		<div class="clear"></div>

	</div>

	<div class="footer w3layouts agileits">
		<p> &copy; 2024 Project Catalogue System. All Rights Reserved </a></p>
		
	</div>

<?php

if(isset($_POST['signin']))
{$u=$_POST['RegNo'];
 $p=$_POST['Password'];
 $c=$_POST['Department'];

 $sql="select * from LMS.user where RegNo='$u'";

 $result = $conn->query($sql);
$row = $result->fetch_assoc();
$x=$row['Password'];
$y=$row['Type'];
if(strcasecmp($x,$p)==0 && !empty($u) && !empty($p))
  {//echo "Login Successful";
   $_SESSION['RegNo']=$u;
   

  if($y=='Admin')
   header('location:admin/index.php');
  else
  	header('location:student/index.php');
        
  }
else 
 { echo "<script type='text/javascript'>alert('Failed to Login! Incorrect Registration Number or Password')</script>";
}
   

}

?>

</body>
<!-- //Body -->

</html>
